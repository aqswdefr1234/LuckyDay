using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GoogleLogIn : MonoBehaviour
{
    public Text logtext;
    public GameObject LogInButton;
    public GameObject LogOutButton;
    public GameObject startButton;

    public void LogIn()
    {
        logtext.text = "";
        GPGSBinder.Inst.Login((success, localUser) => Active());
    }
    void Active()
    {
        startButton.gameObject.SetActive(true);
        LogInButton.gameObject.SetActive(false);
    }
    public void LogOut()
    {
        logtext.text = "";
        GPGSBinder.Inst.Logout();
        logtext.text = "Please log in...";
        startButton.gameObject.SetActive(false);
        LogInButton.gameObject.SetActive(true);
    }
    public void StartGame()
    {
        SceneManager.LoadScene("LobbyScene");
    }

}
