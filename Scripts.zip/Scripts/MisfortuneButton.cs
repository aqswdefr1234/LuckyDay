using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MisfortuneButton : MonoBehaviour
{
    public GameObject MisButton;
    public GameObject blackCircle;
    public GameObject MisFortune;
    public GameObject textCenter;
    public Text doneText;
    public Text coinCounterText;
    private int loadCoin;
    private int saveCoin;

    private void OnTriggerStay(Collider other)

    {
        MisButton.gameObject.SetActive(true);
        textCenter.gameObject.SetActive(false);
    }

    private void OnTriggerExit(Collider other)

    {
        MisButton.gameObject.SetActive(false);
    }

    public void ButtonClick()
    {
        if (PlayerPrefs.GetInt("DoneToday") == 1)
        {
            if (PlayerPrefs.GetInt("DoneMisfortune") == 0)
            {

                coinCounterText.gameObject.SetActive(false);
                GPGSBinder.Inst.LoadCloud("mysave", (success, data) => {
                    if (success)
                    {
                        loadCoin = int.Parse(data);
                        if (loadCoin < 1)
                        {
                            doneText.text = "This requires 1 coin.";
                            Invoke("CoinRefresh", 1.0f);
                        }

                        else
                        {
                            saveCoin = loadCoin - 1;    // ���� ������ ������ 1���Դϴ�.
                            GPGSBinder.Inst.SaveCloud("mysave", saveCoin.ToString(), success => Debug.Log("success"));
                            Invoke("CoinRefresh", 1.0f);
                            blackCircle.gameObject.SetActive(true);
                            MisFortune.gameObject.SetActive(true);
                            PlayerPrefs.SetInt("DoneMisfortune", 1);
                            Invoke("InvokeOn", 14.0f);
                        }
                    }
                });


            }
            else
                doneText.text = "You can throw away your misfortunes only once a day.";
        }
        else
            doneText.text = "Check out 'Today's Luck'.";
    }
    void CoinRefresh()

    {
        coinCounterText.gameObject.SetActive(true);
    }

    void InvokeOn()
    {
        blackCircle.gameObject.SetActive(false);
        MisFortune.gameObject.SetActive(false);
    }

}
