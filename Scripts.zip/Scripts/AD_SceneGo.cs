using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using GoogleMobileAds.Api;
using System;

public class AD_SceneGo : MonoBehaviour
{
    public bool isTestMode;
    public Text LogText;
    public Button RewardAdsBtn;
    //private int coinCounter;
    private int loadCoin;
    private int saveCoin;

    void Start()
    {
        var requestConfiguration = new RequestConfiguration
           .Builder()
           .SetTestDeviceIds(new List<string>() { "" }) // test Device ID
           .build();

        MobileAds.SetRequestConfiguration(requestConfiguration);
        LoadRewardAd();
    }

    void Update()
    {

        RewardAdsBtn.interactable = rewardAd.IsLoaded();
    }

    AdRequest GetAdRequest()
    {
        return new AdRequest.Builder().Build();
    }

    #region ������ ����
    const string rewardTestID = "ca-app-pub-00000000000000000000000";
    const string rewardID = "ca-app-pub-0000000000000/00000000";
    RewardedAd rewardAd;


    void LoadRewardAd()
    {
        

        rewardAd = new RewardedAd(isTestMode ? rewardTestID : rewardID);
        rewardAd.LoadAd(GetAdRequest());
        rewardAd.OnUserEarnedReward += (sender, e) =>
        {
            
            PlayerPrefs.SetInt("a", 0);
            GPGSBinder.Inst.LoadCloud("mysave", (success, data) => {
                if (success)
                {
                    PlayerPrefs.SetInt("a", int.Parse(data) + 2);
                }
                // ���� ������ ������ 2���Դϴ�.
            });
            GPGSBinder.Inst.SaveCloud("mysave", PlayerPrefs.GetInt("a").ToString(), success => LogText.text = $"{success}");
        };
    }

    public void ShowRewardAd()
    {
        rewardAd.Show();
        LoadRewardAd();
        
    }
    #endregion
    
}
