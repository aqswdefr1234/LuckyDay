using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Portal_scripts_F : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)

    {
        Debug.Log(other.name);
        SceneManager.LoadScene("TodayLuck");

    }
}
