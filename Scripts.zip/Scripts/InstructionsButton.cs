using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InstructionsButton : MonoBehaviour
{
    public GameObject menu;
    public GameObject instructionPanel;
    public void InstructionsExit()
    {
        instructionPanel.gameObject.SetActive(false);
    }
    public void InstructionsEntrance()
    {
        menu.gameObject.SetActive(false);
        instructionPanel.gameObject.SetActive(true);
    }
}
