using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class TodayLuckDate : MonoBehaviour
{
    DateTime nowDate;
    void Start()
    {
        int day = 0;
        int month = 0;
        int year = 0;
        nowDate = DateTime.Today;
        day = nowDate.Day;
        month = nowDate.Month;
        year = nowDate.Year;
        PlayerPrefs.SetInt("TodayLuckDateDay", day);
        PlayerPrefs.SetInt("TodayLuckDateMonth", month);
        PlayerPrefs.SetInt("TodayLuckDateYear", year);
        Debug.Log(PlayerPrefs.GetInt("TodayLuckDateDay"));
        Debug.Log(PlayerPrefs.GetInt("TodayLuckDateMonth"));
        Debug.Log(PlayerPrefs.GetInt("TodayLuckDateYear"));
    }
}
