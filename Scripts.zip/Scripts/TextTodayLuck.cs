using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextTodayLuck : MonoBehaviour
{
    public GameObject textToday;
    void Start()
    {
        Invoke("OnInvokeText", 7.0f);
        
    }

    // Update is called once per frame
    void OnInvokeText()
    {
        textToday.gameObject.SetActive(false);
    }
}
