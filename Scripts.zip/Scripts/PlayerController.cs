using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[RequireComponent(typeof(Rigidbody), typeof(BoxCollider))]
public class PlayerController : MonoBehaviour
{
    
    [SerializeField] private FixedJoystick _joystick;
    [SerializeField] private float _moveSpeed;

    
    private void FixedUpdate()
    {
        Vector3 vec = new Vector3(_joystick.Horizontal * _moveSpeed, 0, _joystick.Vertical * _moveSpeed);
        transform.Translate(vec * Time.deltaTime);
    }
}
