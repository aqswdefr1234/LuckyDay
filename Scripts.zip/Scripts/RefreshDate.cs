using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class RefreshDate : MonoBehaviour
{
    DateTime nowDate;
    void Start()
    {
        int currentDateDay = 0;
        int currentDateMonth = 0;
        int currentDateYear = 0;
        nowDate = DateTime.Today;
        currentDateDay = nowDate.Day;
        currentDateMonth = nowDate.Month;
        currentDateYear = nowDate.Year;
        Debug.Log(currentDateDay - PlayerPrefs.GetInt("TodayLuckDateDay"));
        Debug.Log(!((currentDateDay == PlayerPrefs.GetInt("TodayLuckDateDay")) && (currentDateMonth == PlayerPrefs.GetInt("TodayLuckDateMonth")) && (currentDateYear == PlayerPrefs.GetInt("TodayLuckDateYear"))));
        if (!((currentDateDay == PlayerPrefs.GetInt("TodayLuckDateDay")) && (currentDateMonth == PlayerPrefs.GetInt("TodayLuckDateMonth")) && (currentDateYear == PlayerPrefs.GetInt("TodayLuckDateYear"))))
        {
            PlayerPrefs.SetInt("DoneToday", 0);
            PlayerPrefs.SetInt("DoneMisfortune", 0);
        }
    }
}
