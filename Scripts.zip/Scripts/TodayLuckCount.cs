using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TodayLuckCount : MonoBehaviour
{
    public Text textFortune;
    private int fortuneCount;
    private int fortuneCountAvg;
    public Text coinCounterText;
    public GameObject countButton;
    public GameObject fire1;
    public GameObject fire2;
    public GameObject fire3;
    public GameObject fireO;
    public GameObject fireR;
    public GameObject fire_checkCount;
    public GameObject DateObject;
    public GameObject buttonHide;
    private int loadCoin;
    private int saveCoin;

    private void OnTriggerStay(Collider other)
    {
        textFortune.gameObject.SetActive(true);
        countButton.gameObject.SetActive(true);
    }

    private void OnTriggerExit(Collider other)
    {
        countButton.gameObject.SetActive(false);
    }

    public void ButtonClick()
    {
        fire_checkCount.gameObject.SetActive(false);
        if(PlayerPrefs.GetInt("DoneToday") == 0)
        {
            CountFortune();
        }
        else
            textFortune.text = "You can only check once per day.";

    }
    void CountFortune()
    {
        
        
        int fortuneCount = 0;
        float fortuneCountAvg = 0;

        coinCounterText.gameObject.SetActive(false);

        GPGSBinder.Inst.LoadCloud("mysave", (success, data) => {
            if (success)
            {
                loadCoin = int.Parse(data);
                if (loadCoin < 1)
                {
                    textFortune.text = "This requires 1 coin.";
                    Invoke("CoinRefresh", 1.0f);
                }

                else
                {
                    buttonHide.gameObject.SetActive(true);
                    PlayerPrefs.SetInt("DoneToday", 1);
                    saveCoin = loadCoin - 1;    // ���� ������ ������ 1���Դϴ�.
                    GPGSBinder.Inst.SaveCloud("mysave", saveCoin.ToString(), success => Debug.Log("success"));

                    DateObject.gameObject.SetActive(true);

                    for (int i = 0; i < 5; i++)
                    {
                        fortuneCount += Random.Range(1, 11);
                    }
                    fortuneCountAvg = fortuneCount / 5.0f;
                    Debug.Log(fortuneCountAvg);
                    if (fortuneCountAvg < 2.8f)
                    {
                        fire2.gameObject.SetActive(true);
                        textFortune.text = "Very bad...";
                    }
                    else if (fortuneCountAvg < 4.6f)
                    {
                        fire1.gameObject.SetActive(true);
                        textFortune.text = "Little bad...";
                    }
                    else if (fortuneCountAvg < 6.4f)
                    {
                        fire3.gameObject.SetActive(true);
                        textFortune.text = "Normal...";
                    }
                    else if (fortuneCountAvg < 8.2f)
                    {
                        fireO.gameObject.SetActive(true);
                        textFortune.text = "Little good...";
                    }
                    else
                    {
                        fireR.gameObject.SetActive(true);
                        textFortune.text = "Very good...";
                    }
                    Invoke("HideButton", 5.0f);

                }
            }
        });
        Invoke("CoinRefresh", 1.0f);
    }
    void HideButton()
    {
        buttonHide.gameObject.SetActive(false);
    }
    void CoinRefresh()

    {
        coinCounterText.gameObject.SetActive(true);
        textFortune.text = "";
    }
    void TodayFortune()
    {

    }
}
