using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CoinCounter : MonoBehaviour
{
    
    
    public Text coinCountText;
    
    void Start()
    {

        Invoke("DelayCount", 2.0f);
        
    }
    void DelayCount()
    {
        GPGSBinder.Inst.LoadCloud("mysave", (success, data) => coinCountText.text = data);
    }
    
}
