using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CoinActiveButton : MonoBehaviour
{
    public GameObject coin;
    public GameObject coinCountButton;
    public GameObject lightField;
    public Text wishText;
    public Text coinCounterText;
    public Text waitText;
    private int waitWish;
    private int loadCoin;
    private int saveCoin;
    public Text textRequires;

    void Start()
    {
        waitWish = 0;
    }

    public void CoinButton()
    {
        if (waitWish == 0)
            CoinWish();
        else
        {
            waitText.gameObject.SetActive(true);
            Invoke("WaitTextStop", 4.0f);
        }
            
        
    }
    void CoinWish()
    {
        waitWish = 1;
        waitText.gameObject.SetActive(false);
        
        coinCounterText.gameObject.SetActive(false);
        GPGSBinder.Inst.LoadCloud("mysave", (success, data) => {
            if (success)
            {
                loadCoin = int.Parse(data);
                if (loadCoin < 1)
                {
                    textRequires.text = "This requires 1 coin.";
                    Invoke("CoinRefresh", 1.0f);
                }
                else
                {
                    saveCoin = loadCoin - 1;    // ���� ������ ������ 1���Դϴ�.
                    GPGSBinder.Inst.SaveCloud("mysave", saveCoin.ToString(), success => Debug.Log("success"));

                    coin.gameObject.SetActive(true);
                    lightField.gameObject.SetActive(true);
                    wishText.text = "Make a wish for 15 second.";
                    wishText.gameObject.SetActive(true);


                    coinCountButton.gameObject.SetActive(false);
                }
                
                
            }
            
        });
        Invoke("CoinRefresh", 1.0f);
        Invoke("OnInvoke", 14.0f);
    }

    void WaitTextStop()

    {
        waitText.gameObject.SetActive(false);
    }

    void CoinRefresh()

    {
        coinCounterText.gameObject.SetActive(true);
        textRequires.text = "";
    }

    void OnInvoke()

    {
        coin.gameObject.SetActive(false);
        lightField.gameObject.SetActive(false);
        wishText.gameObject.SetActive(false);
        waitWish = 0;
    }

}
