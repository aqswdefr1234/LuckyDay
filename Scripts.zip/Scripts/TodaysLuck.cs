using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;



public class TodaysLuck : MonoBehaviour
{
    public GameObject fireCircleButton;
    public GameObject fireCircle;
    public GameObject marble;
    public GameObject fire;
    public GameObject fire_crew;
    
    public Text textFortune;
    private int fortuneCount;
    private int fortuneCountAvg;

    private void OnTriggerStay(Collider other)
    {
        fireCircleButton.gameObject.SetActive(true);
    }

    private void OnTriggerExit(Collider other)
    {
        fireCircleButton.gameObject.SetActive(false);
    }

    public void ButtonClick()
    {

        fireCircle.gameObject.SetActive(true);



        Invoke("OnInvoke", 7.9f);

    }
    void OnInvoke()
    {
        
        marble.gameObject.SetActive(true);
        fire.gameObject.SetActive(false);
        fireCircle.gameObject.SetActive(false);
        fireCircleButton.gameObject.SetActive(false);
        fire_crew.gameObject.SetActive(true);

    }

    public void CountFortune()
    {

        int fortuneCount = 0;
        float fortuneCountAvg = 0;
        for (int i = 0; i< 5; i++) 
        {
            fortuneCount += Random.Range(1, 11);
        }
        fortuneCountAvg = fortuneCount / 5.0f;
        Debug.Log(fortuneCountAvg);
        

        if (fortuneCountAvg < 3)
            textFortune.text = "Very bad...";
        else if (fortuneCountAvg < 5)
            textFortune.text = "Little bad...";
        else if (fortuneCountAvg < 7)
            textFortune.text = "Normal...";
        else if (fortuneCountAvg < 9)
            textFortune.text = "Little good...";
        else
            textFortune.text = "Very good...";

    }
}
        

